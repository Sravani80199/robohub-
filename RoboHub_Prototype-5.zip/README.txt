# RoboHub Prototype
A browser-based prototype for an AI + robotics platform.

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Use the sidebar to test Home, Robots, AI Assistant, Learning, Control and Profile.

## Important
This is a front-end prototype. The robot controls and AI responses are simulated. A real app would need a backend, authentication, database, AI API, and robot communication layer.
